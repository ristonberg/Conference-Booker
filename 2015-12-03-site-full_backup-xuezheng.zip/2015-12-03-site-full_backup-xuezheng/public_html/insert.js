var mysql = require('mysql');

var connection = mysql.createConnection({
	host: '176.32.230.252',
	user: 'cl57-xuezheng',
	password: 'HnsXB/zKk',
	database: 'cl57-xuezheng',

});


connection.connect(function(err){
  if(err){
    console.log('Error connecting to Db');
    return;
  }
  console.log('Connection established');
});


// connection.connect();

var user = {
	firstname:"testing",
	lastname:'something',
	email:'1@1.com',
	password:"sdq"
};

var query = connection.query('insert into users set ?', user, function(err, result){
	if(err){
    console.log('Error connecting to Db');
    return;
  }
  console.log('Connection established');
});







